<?php include 'managerheader.php'; ?>
<style type="text/css">
	aside{
		text-align: center;
		font-size: 35px;

	}

	 li{
		list-style-type: none;
		text-align: center;
	}

	a{
		color: darkblue;
	}

</style>

<!DOCTYPE html>
<html>
<body>

    <div class="container-fluid" style = "background-color: #b0c4de;">
    <aside>
        <nav>
      <p><h1 style="font-size: 50px;">Select an option below:</h1></p>
      <p><a href="employeecreateaccount.php">Create Employee Account</a></p>
      <hr style="border-width: 3px; border-color: black;" >
      <p><a href="employeelist.php">View Employee List</a></p>
			<hr style="border-width: 3px; border-color: black;" >
      <p><a href="viewtimes.php">View Times</a></p>
      </nav>
      </aside>
</div>
  </body>

</html>
